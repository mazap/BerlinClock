package com.ubs.opsit.interviews.converters;


public interface MinutesConverter {
    String convertMinutes(int minutes);
}
