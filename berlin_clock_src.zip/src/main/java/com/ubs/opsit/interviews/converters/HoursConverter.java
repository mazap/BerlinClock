package com.ubs.opsit.interviews.converters;

public interface HoursConverter {
    String convertHours(int hours);
}
