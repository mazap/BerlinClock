package com.ubs.opsit.interviews.converters;

public interface SecondsConverter {
    String convertSeconds(int seconds);
}
