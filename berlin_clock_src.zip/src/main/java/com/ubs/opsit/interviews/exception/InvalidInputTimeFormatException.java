package com.ubs.opsit.interviews.exception;

public class InvalidInputTimeFormatException extends Exception {

    public InvalidInputTimeFormatException(String message) {
        super(message);
    }
}
